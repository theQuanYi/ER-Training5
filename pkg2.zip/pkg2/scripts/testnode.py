#!/usr/bin/env python
import rospy
from pkg1.addlib import add
if __name__ == '__main__':
    rospy.init_node('test_node')
    c = add(2, 3)
    print(c)
