#!/usr/bin/env python3

from __future__ import print_function
from pkg2.srv import AddTwoInts,AddTwoIntsResponse,PubToTopic,PubToTopicResponse
from std_msgs.msg import String
import rospy

def handle_add_two_ints(req):
    gain = rospy.get_param("/gain")
    print("Returning [(%s + %s) * %s = %s]"%(req.a, req.b, gain, (req.a + req.b)))
    res = gain * (req.a + req.b)
    return AddTwoIntsResponse(res)

def handle_pub_to_topic(cont):
    pub = rospy.Publisher('chatter', String, queue_size=10)
    rate = rospy.Rate(100)
    print("Publishing")
    while not rospy.is_shutdown():
        pub.publish("Message printed")
        print("Message printed")
        rate.sleep()
    return PubToTopicResponse("Message printed")


def node3_server():
    rospy.init_node('node2')
    s1 = rospy.Service('add_two_ints', AddTwoInts, handle_add_two_ints)
    s2 = rospy.Service('pub_to_topic', PubToTopic, handle_pub_to_topic)
    print("Ready to run.")
    rospy.spin()
#    s1.spin()
#    s2.spin()

if __name__ == "__main__":
    node3_server()
 #   rate = rospy.Rate(100)
 #   while not rospy.is_shutdown():
 #       pub_to_topic = rospy.ServiceProxy('pub_to_topic', PubToTopic)
 #       hello_str = pub_to_topic(1)
 #       pub.publish(hello_str)
 #       rate.sleep()
