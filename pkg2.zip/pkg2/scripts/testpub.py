#!/usr/bin/env python3
from __future__ import print_function

import rospy
from PubToTopic.srv import *

def pub_to_topic_client():
    rospy.wait_for_service('pub_to_topic')
    try:
        pub_to_topic = rospy.ServiceProxy('pub_to_topic', PubToTopic)
        resstr = pub_to_topic()
        return resstr

if __name__ == "__main__":
    print("Requesting message")
    print(pub_to_topic_client())

